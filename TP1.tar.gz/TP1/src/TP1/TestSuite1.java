package TP1;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;

@RunWith( value = Suite.class )
@SuiteClasses( value = { CommandeVide1Test.class, CommandeVide2Test.class, CommandeVide3Test.class } )
public class TestSuite1 {}