package TP1;

/**
 * Enum des différents types de fichiers accessible pour une commande
 */
public enum TypeFichier {
	FICHIER,DOSSIER,FICHIERETDOSSIER
}
