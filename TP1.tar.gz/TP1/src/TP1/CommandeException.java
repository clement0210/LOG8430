package TP1;

/**
 * Created by clement0210 on 14-01-30.
 */
public class CommandeException extends Exception {
    public CommandeException(String s) {
        super(s);
    }
}
